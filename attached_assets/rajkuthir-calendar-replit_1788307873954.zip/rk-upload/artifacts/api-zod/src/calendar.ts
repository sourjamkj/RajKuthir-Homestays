/**
 * artifacts/api-zod/src/calendar.ts
 * Shared request/response contracts. Import in both server routes and client.
 */
import { z } from "zod";

const isoDate = z
  .string()
  .regex(/^\d{4}-\d{2}-\d{2}$/, "Use YYYY-MM-DD");

/** POST /calendar/block */
export const BlockDatesBody = z
  .object({
    startDate: isoDate,
    endDate: isoDate,
    title: z.string().trim().max(120).optional(),
    note: z.string().trim().max(500).optional(),
  })
  .refine((v) => v.startDate < v.endDate, {
    message: "Check-out (endDate) must be after check-in (startDate).",
    path: ["endDate"],
  });
export type BlockDatesBody = z.infer<typeof BlockDatesBody>;

/** A calendar event as returned to the ADMIN UI. */
export const CalendarEventDto = z.object({
  id: z.string(),
  source: z.enum(["manual", "direct", "bookingCom", "airbnb", "makeMyTrip"]),
  startDate: isoDate,
  endDate: isoDate,
  title: z.string().nullable(),
  note: z.string().nullable().optional(),
  editable: z.boolean(), // true for manual/direct
});
export type CalendarEventDto = z.infer<typeof CalendarEventDto>;

export const ListEventsResponse = z.object({
  events: z.array(CalendarEventDto),
});
export type ListEventsResponse = z.infer<typeof ListEventsResponse>;

/** GET /calendar/public — minimal, no PII. */
export const PublicBlocksResponse = z.object({
  blocks: z.array(z.object({ startDate: isoDate, endDate: isoDate })),
});
export type PublicBlocksResponse = z.infer<typeof PublicBlocksResponse>;

/** POST /calendar/sync response (reuse your existing shape if you prefer). */
export const SyncSourceStatus = z.object({
  source: z.enum(["bookingCom", "airbnb", "makeMyTrip"]),
  label: z.string(),
  status: z.enum(["connected", "missing", "error"]),
  eventCount: z.number(),
  message: z.string(),
  lastSyncedAt: z.string().nullable(),
});

export const SyncCalendarsResponse = z.object({
  syncedAt: z.string(),
  totalEvents: z.number(),
  sources: z.array(SyncSourceStatus),
});
export type SyncCalendarsResponse = z.infer<typeof SyncCalendarsResponse>;
