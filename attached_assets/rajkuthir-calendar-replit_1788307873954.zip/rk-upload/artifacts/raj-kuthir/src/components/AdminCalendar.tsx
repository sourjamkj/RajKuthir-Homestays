/**
 * artifacts/raj-kuthir/src/components/AdminCalendar.tsx
 *
 * Airbnb-style calendar for the owner:
 *   • click a start date, click an end date  → block that range
 *   • existing blocks are colour-coded by source
 *   • manual/direct blocks have an "unblock" button; OTA ones are read-only
 *
 * Deps already in your project: react-day-picker ^9, date-fns ^3,
 * @tanstack/react-query, lucide-react. Render this inside your
 * <Show when="signed-in"> admin section.
 */
import { useMemo, useState } from "react";
import { DayPicker, type DateRange } from "react-day-picker";
import { addDays, format, parseISO, eachDayOfInterval } from "date-fns";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Loader2, Lock, Trash2, Plus } from "lucide-react";
import "react-day-picker/dist/style.css";

type Source = "manual" | "direct" | "bookingCom" | "airbnb" | "makeMyTrip";

type CalendarEventDto = {
  id: string;
  source: Source;
  startDate: string; // YYYY-MM-DD
  endDate: string; // exclusive
  title: string | null;
  note?: string | null;
  editable: boolean;
};

const SOURCE_META: Record<Source, { label: string; dot: string; chip: string }> = {
  manual: { label: "Host block", dot: "#5A3E2B", chip: "bg-[#5A3E2B] text-white" },
  direct: { label: "Direct", dot: "#7A8065", chip: "bg-[#7A8065] text-white" },
  bookingCom: { label: "Booking.com", dot: "#A65E45", chip: "bg-[#A65E45] text-white" },
  airbnb: { label: "Airbnb", dot: "#C15B4A", chip: "bg-[#C15B4A] text-white" },
  makeMyTrip: { label: "MakeMyTrip", dot: "#28382D", chip: "bg-[#28382D] text-white" },
};

const API = "/api/calendar";

async function api<T>(path: string, init?: RequestInit): Promise<T> {
  const res = await fetch(`${API}${path}`, {
    credentials: "include",
    headers: { "Content-Type": "application/json" },
    ...init,
  });
  if (!res.ok) {
    const body = await res.json().catch(() => ({}));
    throw new Error(body.error ?? `Request failed (${res.status})`);
  }
  return res.status === 204 ? (undefined as T) : res.json();
}

/** Expand an event into the individual nights it occupies (end is exclusive). */
function nightsOf(ev: { startDate: string; endDate: string }): Date[] {
  const start = parseISO(ev.startDate);
  const endExclusive = parseISO(ev.endDate);
  if (endExclusive <= start) return [start];
  return eachDayOfInterval({ start, end: addDays(endExclusive, -1) });
}

export function AdminCalendar() {
  const qc = useQueryClient();
  const [range, setRange] = useState<DateRange | undefined>();
  const [title, setTitle] = useState("");
  const [error, setError] = useState<string | null>(null);

  const { data, isLoading } = useQuery({
    queryKey: ["calendar-events"],
    queryFn: () => api<{ events: CalendarEventDto[] }>("/events"),
  });
  const events = data?.events ?? [];

  // Map each night → the event covering it, for colouring the day cells.
  const nightIndex = useMemo(() => {
    const m = new Map<string, CalendarEventDto>();
    for (const ev of events) {
      for (const d of nightsOf(ev)) m.set(format(d, "yyyy-MM-dd"), ev);
    }
    return m;
  }, [events]);

  const modifiers = useMemo(() => {
    const bySource: Record<Source, Date[]> = {
      manual: [], direct: [], bookingCom: [], airbnb: [], makeMyTrip: [],
    };
    for (const [iso, ev] of nightIndex) bySource[ev.source].push(parseISO(iso));
    return bySource;
  }, [nightIndex]);

  const blockMutation = useMutation({
    mutationFn: (body: { startDate: string; endDate: string; title?: string }) =>
      api<CalendarEventDto>("/block", {
        method: "POST",
        body: JSON.stringify(body),
      }),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["calendar-events"] });
      setRange(undefined);
      setTitle("");
      setError(null);
    },
    onError: (e: Error) => setError(e.message),
  });

  const unblockMutation = useMutation({
    mutationFn: (id: string) => api<void>(`/block/${id}`, { method: "DELETE" }),
    onSuccess: () => qc.invalidateQueries({ queryKey: ["calendar-events"] }),
    onError: (e: Error) => setError(e.message),
  });

  function handleBlock() {
    if (!range?.from) return;
    // If only one day picked, treat as a single night: end = next day.
    const from = range.from;
    const to = range.to ?? addDays(range.from, 1);
    // react-day-picker "to" is the last selected day (inclusive); our API end
    // is exclusive, so push it one day forward.
    const endExclusive = range.to ? addDays(to, 1) : to;
    blockMutation.mutate({
      startDate: format(from, "yyyy-MM-dd"),
      endDate: format(endExclusive, "yyyy-MM-dd"),
      title: title.trim() || undefined,
    });
  }

  const upcoming = useMemo(
    () =>
      [...events].sort((a, b) => a.startDate.localeCompare(b.startDate)),
    [events],
  );

  return (
    <div className="grid gap-8 md:grid-cols-[auto,1fr]">
      {/* Calendar */}
      <div className="rounded-2xl border border-border bg-card p-5">
        <h3 className="font-journal text-xl text-primary">Availability</h3>
        <p className="mt-1 text-xs text-muted-foreground">
          Click a check-in date, then a check-out date, to block the stay.
        </p>

        <DayPicker
          mode="range"
          selected={range}
          onSelect={setRange}
          numberOfMonths={2}
          weekStartsOn={1}
          modifiers={modifiers}
          modifiersStyles={{
            manual: { backgroundColor: SOURCE_META.manual.dot, color: "#fff" },
            direct: { backgroundColor: SOURCE_META.direct.dot, color: "#fff" },
            bookingCom: { backgroundColor: SOURCE_META.bookingCom.dot, color: "#fff" },
            airbnb: { backgroundColor: SOURCE_META.airbnb.dot, color: "#fff" },
            makeMyTrip: { backgroundColor: SOURCE_META.makeMyTrip.dot, color: "#fff" },
          }}
        />

        {/* Legend */}
        <div className="mt-3 flex flex-wrap gap-3">
          {(Object.keys(SOURCE_META) as Source[]).map((s) => (
            <span key={s} className="flex items-center gap-1.5 text-[11px] text-muted-foreground">
              <span
                className="inline-block h-3 w-3 rounded-full"
                style={{ backgroundColor: SOURCE_META[s].dot }}
              />
              {SOURCE_META[s].label}
            </span>
          ))}
        </div>

        {/* Block action */}
        <div className="mt-5 flex flex-col gap-3 border-t border-border pt-4">
          <input
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            placeholder="Optional label (e.g. Maintenance, Family stay)"
            className="rounded-lg border border-border bg-background px-3 py-2 text-sm"
          />
          <button
            type="button"
            disabled={!range?.from || blockMutation.isPending}
            onClick={handleBlock}
            className="flex items-center justify-center gap-2 rounded-full bg-primary px-5 py-2.5 text-xs font-bold uppercase tracking-[.12em] text-primary-foreground disabled:opacity-50"
          >
            {blockMutation.isPending ? (
              <Loader2 className="h-4 w-4 animate-spin" />
            ) : (
              <Plus className="h-4 w-4" />
            )}
            Block selected dates
          </button>
          {error && <p className="text-xs text-[#A65E45]">{error}</p>}
        </div>
      </div>

      {/* Upcoming list */}
      <div className="rounded-2xl border border-border bg-card p-5">
        <h3 className="font-journal text-xl text-primary">Blocked & booked</h3>
        {isLoading ? (
          <p className="mt-4 flex items-center gap-2 text-sm text-muted-foreground">
            <Loader2 className="h-4 w-4 animate-spin" /> Loading…
          </p>
        ) : upcoming.length === 0 ? (
          <p className="mt-4 text-sm text-muted-foreground">
            Nothing blocked yet. Your villa shows fully available.
          </p>
        ) : (
          <ul className="mt-4 flex flex-col gap-2">
            {upcoming.map((ev) => (
              <li
                key={ev.id}
                className="flex items-center justify-between gap-3 rounded-xl border border-border px-4 py-3"
              >
                <div className="min-w-0">
                  <div className="flex items-center gap-2">
                    <span
                      className={`rounded-full px-2 py-0.5 text-[10px] font-bold uppercase tracking-wide ${SOURCE_META[ev.source].chip}`}
                    >
                      {SOURCE_META[ev.source].label}
                    </span>
                    <span className="truncate text-sm font-medium text-foreground">
                      {ev.title ?? "Reserved"}
                    </span>
                  </div>
                  <p className="mt-1 text-xs text-muted-foreground">
                    {format(parseISO(ev.startDate), "d MMM")} →{" "}
                    {format(parseISO(ev.endDate), "d MMM yyyy")}
                  </p>
                </div>

                {ev.editable ? (
                  <button
                    type="button"
                    onClick={() => unblockMutation.mutate(ev.id)}
                    disabled={unblockMutation.isPending}
                    aria-label="Unblock"
                    className="flex items-center gap-1 rounded-full border border-border px-3 py-1.5 text-[11px] font-semibold text-[#A65E45] hover:bg-[#A65E45]/5 disabled:opacity-50"
                  >
                    <Trash2 className="h-3.5 w-3.5" /> Unblock
                  </button>
                ) : (
                  <span className="flex items-center gap-1 text-[11px] text-muted-foreground">
                    <Lock className="h-3.5 w-3.5" /> OTA
                  </span>
                )}
              </li>
            ))}
          </ul>
        )}
      </div>
    </div>
  );
}
