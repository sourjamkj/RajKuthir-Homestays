/**
 * artifacts/db/src/schema/calendar.ts  (or add to your existing schema)
 *
 * Single source of truth for all calendar blocks & bookings.
 * Run `pnpm drizzle-kit push` after adding this.
 */
import {
  pgTable,
  uuid,
  text,
  date,
  timestamp,
  pgEnum,
  uniqueIndex,
  index,
} from "drizzle-orm/pg-core";

export const calendarSourceEnum = pgEnum("calendar_source", [
  "manual", // admin blocked it by hand (Airbnb-style)
  "direct", // booked through your own website
  "bookingCom",
  "airbnb",
  "makeMyTrip",
]);

export const calendarStatusEnum = pgEnum("calendar_status", [
  "confirmed",
  "cancelled",
]);

export const calendarEvents = pgTable(
  "calendar_events",
  {
    id: uuid("id").primaryKey().defaultRandom(),

    source: calendarSourceEnum("source").notNull(),

    // Original UID from the OTA feed. NULL for manual/direct rows.
    // Used to keep imports idempotent (see repo upsert).
    externalUid: text("external_uid"),

    // start = first blocked night (inclusive)
    // end   = checkout (EXCLUSIVE) — the checkout day is free again
    startDate: date("start_date").notNull(),
    endDate: date("end_date").notNull(),

    status: calendarStatusEnum("status").notNull().default("confirmed"),

    // Free-text label: guest name (direct) or reason ("Maintenance", "Family").
    title: text("title"),

    // Optional private admin note, never exposed in the public feed.
    note: text("note"),

    createdAt: timestamp("created_at", { withTimezone: true })
      .notNull()
      .defaultNow(),
    updatedAt: timestamp("updated_at", { withTimezone: true })
      .notNull()
      .defaultNow(),
  },
  (t) => ({
    // Dedupe imported OTA events: one row per (source + externalUid).
    sourceUidUnique: uniqueIndex("calendar_source_uid_uniq").on(
      t.source,
      t.externalUid,
    ),
    // Fast range lookups for availability queries.
    rangeIdx: index("calendar_range_idx").on(t.startDate, t.endDate),
    sourceIdx: index("calendar_source_idx").on(t.source),
  }),
);

export type CalendarEvent = typeof calendarEvents.$inferSelect;
export type NewCalendarEvent = typeof calendarEvents.$inferInsert;
