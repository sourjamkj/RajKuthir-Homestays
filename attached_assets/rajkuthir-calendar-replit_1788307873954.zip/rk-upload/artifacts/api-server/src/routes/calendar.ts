/**
 * artifacts/api-server/src/routes/calendar.ts  (REPLACEMENT)
 *
 * DB-backed. Manual block/unblock. Per-OTA export feed (no feedback loop).
 * Reuses your SSRF guard, timing-safe token, and RFC-5545 parser.
 */
import { Router, type IRouter } from "express";
import { getAuth } from "@clerk/express";
import crypto from "node:crypto";
import {
  BlockDatesBody,
  type CalendarEventDto,
} from "@workspace/api-zod";
import {
  listAllEvents,
  listPublicBlocks,
  listFeedEvents,
  createManualBlock,
  deleteOwnedEvent,
  replaceSourceEvents,
  OWNED_SOURCES,
  type CalendarSource,
} from "../lib/calendar-repo";

const router: IRouter = Router();

// ---------------------------------------------------------------------------
// Config
// ---------------------------------------------------------------------------
type ImportSource = "bookingCom" | "airbnb" | "makeMyTrip";

const SOURCE_DEFINITIONS: Array<{ key: ImportSource; label: string }> = [
  { key: "bookingCom", label: "Booking.com" },
  { key: "airbnb", label: "Airbnb" },
  { key: "makeMyTrip", label: "MakeMyTrip" },
];

const SECURE_FEED_URLS: Partial<Record<ImportSource, string | undefined>> = {
  bookingCom: process.env.RAJ_KUTHIR_BOOKING_ICAL_URL,
  airbnb: process.env.RAJ_KUTHIR_AIRBNB_ICAL_URL,
  makeMyTrip: process.env.RAJ_KUTHIR_MAKEMYTRIP_ICAL_URL,
};

const CALENDAR_FEED_TOKEN = process.env.RAJ_KUTHIR_CALENDAR_FEED_TOKEN;

const ADMIN_USER_IDS = (process.env.RAJ_KUTHIR_ADMIN_USER_IDS ?? "")
  .split(",")
  .map((s) => s.trim())
  .filter(Boolean);

// ---------------------------------------------------------------------------
// Auth — allowlist, not "any signed-in user"
// ---------------------------------------------------------------------------
const requireAdmin = (req: any, res: any, next: any) => {
  const { userId } = getAuth(req);
  if (!userId) {
    res.status(401).json({ error: "Admin sign-in required." });
    return;
  }
  // If an allowlist is set, enforce it. (Set RAJ_KUTHIR_ADMIN_USER_IDS.)
  if (ADMIN_USER_IDS.length > 0 && !ADMIN_USER_IDS.includes(userId)) {
    res.status(403).json({ error: "This account is not an authorised admin." });
    return;
  }
  req.userId = userId;
  next();
};

// ---------------------------------------------------------------------------
// SSRF guard (kept from your version)
// ---------------------------------------------------------------------------
function isSafeFeedUrl(value: string): boolean {
  try {
    const url = new URL(value);
    if (!["http:", "https:"].includes(url.protocol)) return false;
    const h = url.hostname.toLowerCase();
    if (
      h === "localhost" ||
      h.endsWith(".local") ||
      h === "0.0.0.0" ||
      h === "::1" ||
      h.startsWith("127.") ||
      h.startsWith("10.") ||
      h.startsWith("192.168.") ||
      h.startsWith("169.254.") ||
      h.startsWith("fc") ||
      h.startsWith("fd") // IPv6 ULA
    ) {
      return false;
    }
    return !/^172\.(1[6-9]|2\d|3[01])\./.test(h);
  } catch {
    return false;
  }
}

// ---------------------------------------------------------------------------
// RFC 5545 parsing (kept from your version, trimmed)
// ---------------------------------------------------------------------------
function unfold(value: string): string[] {
  const norm = value.replace(/\r\n/g, "\n").replace(/\r/g, "\n");
  const out: string[] = [];
  for (const line of norm.split("\n")) {
    if ((line.startsWith(" ") || line.startsWith("\t")) && out.length) {
      out[out.length - 1] += line.slice(1);
    } else out.push(line);
  }
  return out;
}

function prop(lines: string[], name: string): string | null {
  const line = lines.find(
    (l) => l.startsWith(`${name}:`) || l.startsWith(`${name};`),
  );
  if (!line) return null;
  const i = line.indexOf(":");
  return i >= 0 ? line.slice(i + 1) : null;
}

function toIsoDate(raw: string): string | null {
  const m = raw.trim().match(/^(\d{4})(\d{2})(\d{2})/);
  return m ? `${m[1]}-${m[2]}-${m[3]}` : null;
}

function unescape(v: string): string {
  return v
    .replace(/\\n/gi, " ")
    .replace(/\\,/g, ",")
    .replace(/\\;/g, ";")
    .replace(/\\\\/g, "\\")
    .trim();
}

type ParsedEvent = {
  externalUid: string;
  startDate: string;
  endDate: string;
  title: string | null;
};

function parseIcs(content: string, source: ImportSource): ParsedEvent[] {
  const lines = unfold(content);
  const events: ParsedEvent[] = [];
  let cur: string[] | null = null;

  for (const line of lines) {
    if (line === "BEGIN:VEVENT") cur = [];
    else if (line === "END:VEVENT" && cur) {
      const start = prop(cur, "DTSTART");
      const end = prop(cur, "DTEND");
      const status = prop(cur, "STATUS")?.toUpperCase();
      const transp = prop(cur, "TRANSP")?.toUpperCase();
      const s = start ? toIsoDate(start) : null;
      const e = end ? toIsoDate(end) : null;

      if (s && e && status !== "CANCELLED" && transp !== "TRANSPARENT") {
        const uid = prop(cur, "UID") ?? `${s}-${e}-${events.length}`;
        const summary = prop(cur, "SUMMARY");
        events.push({
          externalUid: uid.replace(/[^a-zA-Z0-9_@.-]/g, "-"),
          startDate: s,
          endDate: e,
          title: summary ? unescape(summary) : null,
        });
      }
      cur = null;
    } else if (cur) cur.push(line);
  }
  return events;
}

async function fetchFeed(url: string): Promise<string> {
  if (!isSafeFeedUrl(url)) throw new Error("Enter a public http(s) feed URL.");
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 12_000);
  try {
    const res = await fetch(url, {
      headers: {
        Accept: "text/calendar,text/plain;q=0.9,*/*;q=0.1",
        "User-Agent": "Raj-Kuthir-Calendar-Sync/1.0",
      },
      signal: controller.signal,
      redirect: "error", // don't follow redirects (SSRF hardening)
    });
    if (!res.ok) throw new Error(`Feed returned ${res.status}.`);
    const text = await res.text();
    if (text.length > 2_000_000) throw new Error("Feed exceeds 2 MB limit.");
    return text;
  } finally {
    clearTimeout(timeout);
  }
}

// ---------------------------------------------------------------------------
// iCal export rendering
// ---------------------------------------------------------------------------
function esc(v: string): string {
  return v
    .replace(/\\/g, "\\\\")
    .replace(/;/g, "\\;")
    .replace(/,/g, "\\,")
    .replace(/\r?\n/g, "\\n");
}
const icsDate = (v: string) => v.replaceAll("-", "");

function renderIcs(
  events: { id: string; startDate: string; endDate: string }[],
): string {
  const stamp =
    new Date().toISOString().replace(/[-:]/g, "").split(".")[0] + "Z";
  const rows = [
    "BEGIN:VCALENDAR",
    "VERSION:2.0",
    "PRODID:-//Raj Kuthir Homestays//Sobuj Potro//EN",
    "CALSCALE:GREGORIAN",
    "METHOD:PUBLISH",
    "X-WR-CALNAME:Raj Kuthir Sobuj Potro",
    "X-WR-TIMEZONE:Asia/Kolkata",
  ];
  for (const e of events) {
    rows.push(
      "BEGIN:VEVENT",
      `UID:${esc(e.id)}@rajkuthirhomestays`,
      `DTSTAMP:${stamp}`,
      `DTSTART;VALUE=DATE:${icsDate(e.startDate)}`,
      `DTEND;VALUE=DATE:${icsDate(e.endDate)}`,
      "SUMMARY:Reserved - Raj Kuthir",
      "TRANSP:OPAQUE",
      "END:VEVENT",
    );
  }
  rows.push("END:VCALENDAR");
  return rows.join("\r\n") + "\r\n";
}

function validFeedToken(value: unknown): value is string {
  if (!CALENDAR_FEED_TOKEN || typeof value !== "string") return false;
  const a = Buffer.from(CALENDAR_FEED_TOKEN);
  const b = Buffer.from(value);
  return a.length === b.length && crypto.timingSafeEqual(a, b);
}

// ===========================================================================
// ROUTES
// ===========================================================================

/** Admin: full event list for the calendar UI. */
router.get("/calendar/events", requireAdmin, async (_req, res) => {
  const rows = await listAllEvents();
  const events: CalendarEventDto[] = rows.map((r) => ({
    id: r.id,
    source: r.source,
    startDate: r.startDate,
    endDate: r.endDate,
    title: r.title,
    note: r.note,
    editable: (OWNED_SOURCES as string[]).includes(r.source),
  }));
  res.setHeader("Cache-Control", "no-store");
  res.json({ events });
});

/** Public: minimal blocked ranges for the guest availability calendar. */
router.get("/calendar/public", async (_req, res) => {
  const blocks = await listPublicBlocks();
  res.setHeader("Cache-Control", "public, max-age=300");
  res.json({ blocks });
});

/** Admin: block a date range (Airbnb-style). */
router.post("/calendar/block", requireAdmin, async (req, res) => {
  const parsed = BlockDatesBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.issues[0]?.message ?? "Invalid." });
    return;
  }
  const created = await createManualBlock(parsed.data);
  res.status(201).json({
    id: created.id,
    source: created.source,
    startDate: created.startDate,
    endDate: created.endDate,
    title: created.title,
    note: created.note,
    editable: true,
  });
});

/** Admin: unblock (delete a manual/direct event). */
router.delete("/calendar/block/:id", requireAdmin, async (req, res) => {
  const ok = await deleteOwnedEvent(req.params.id);
  if (!ok) {
    res
      .status(404)
      .json({ error: "Not found, or it is an OTA booking that can't be removed here." });
    return;
  }
  res.status(204).end();
});

/** Admin: import all OTA feeds → persist to DB. */
router.post("/calendar/sync", requireAdmin, async (req, res) => {
  const syncedAt = new Date().toISOString();
  const sources = [];
  let total = 0;

  for (const def of SOURCE_DEFINITIONS) {
    const url = (req.body?.[def.key] as string) || SECURE_FEED_URLS[def.key];
    if (!url) {
      sources.push({
        source: def.key,
        label: def.label,
        status: "missing" as const,
        eventCount: 0,
        message: "Add an iCal feed URL to connect this source.",
        lastSyncedAt: null,
      });
      continue;
    }
    try {
      const parsed = parseIcs(await fetchFeed(url), def.key);
      const count = await replaceSourceEvents(def.key, parsed);
      total += count;
      sources.push({
        source: def.key,
        label: def.label,
        status: "connected" as const,
        eventCount: count,
        message: count ? "Feed synced & saved." : "Connected; no blocked dates.",
        lastSyncedAt: syncedAt,
      });
      req.log?.info({ source: def.key, count }, "Calendar synced");
    } catch (err) {
      const message = err instanceof Error ? err.message : "Unable to read feed.";
      sources.push({
        source: def.key,
        label: def.label,
        status: "error" as const,
        eventCount: 0,
        message,
        lastSyncedAt: null,
      });
      req.log?.warn({ source: def.key, err: message }, "Sync failed");
    }
  }
  res.json({ syncedAt, totalEvents: total, sources });
});

/** Admin: show the 3 per-OTA export URLs to paste into each extranet. */
router.get("/calendar/feed-info", requireAdmin, (req, res) => {
  if (!CALENDAR_FEED_TOKEN) {
    res.status(503).json({ error: "Outbound feed token not configured." });
    return;
  }
  const proto =
    req.headers["x-forwarded-proto"]?.toString().split(",")[0].trim() ||
    req.protocol;
  const host =
    req.headers["x-forwarded-host"]?.toString().split(",")[0].trim() ||
    req.get("host");
  const base = `${proto}://${host}/api/calendar/feed`;

  const make = (exclude: ImportSource) =>
    `${base}?token=${encodeURIComponent(CALENDAR_FEED_TOKEN)}&exclude=${exclude}`;

  res.setHeader("Cache-Control", "no-store");
  res.json({
    // Give each OTA the URL that excludes ITS OWN events (no feedback loop).
    bookingCom: make("bookingCom"),
    airbnb: make("airbnb"),
    makeMyTrip: make("makeMyTrip"),
    // A full feed (everything) for any other aggregator.
    all: `${base}?token=${encodeURIComponent(CALENDAR_FEED_TOKEN)}`,
  });
});

/** Token-protected export. Reads from DB. ?exclude=<source> skips that source. */
router.get("/calendar/feed", async (req, res) => {
  if (!validFeedToken(req.query.token)) {
    res.status(401).type("text/plain").send("Invalid calendar feed token.");
    return;
  }
  const exclude = req.query.exclude as CalendarSource | undefined;
  const valid: CalendarSource[] = [
    "manual",
    "direct",
    "bookingCom",
    "airbnb",
    "makeMyTrip",
  ];
  const events = await listFeedEvents(
    exclude && valid.includes(exclude) ? exclude : undefined,
  );
  res.setHeader("Cache-Control", "no-cache, max-age=0");
  res.type("text/calendar").send(renderIcs(events));
});

export default router;
