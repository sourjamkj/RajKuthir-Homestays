/**
 * artifacts/api-server/src/lib/calendar-repo.ts
 *
 * All DB access for the calendar lives here. Routes stay thin.
 * Assumes you export a Drizzle instance `db` from @workspace/db.
 */
import { and, eq, gt, lt, ne, inArray, asc } from "drizzle-orm";
import { db } from "@workspace/db";
import {
  calendarEvents,
  type CalendarEvent,
  type NewCalendarEvent,
} from "@workspace/db/schema";

export type CalendarSource = CalendarEvent["source"];

/** Sources that are editable in the admin UI (created by you, not OTAs). */
export const OWNED_SOURCES: CalendarSource[] = ["manual", "direct"];

/** Every confirmed event, newest-start first — for the admin calendar. */
export async function listAllEvents(): Promise<CalendarEvent[]> {
  return db
    .select()
    .from(calendarEvents)
    .where(eq(calendarEvents.status, "confirmed"))
    .orderBy(asc(calendarEvents.startDate));
}

/**
 * Public availability — only what a guest needs: the blocked ranges.
 * We do NOT leak source, guest names or notes here.
 */
export async function listPublicBlocks(): Promise<
  { startDate: string; endDate: string }[]
> {
  const rows = await db
    .select({
      startDate: calendarEvents.startDate,
      endDate: calendarEvents.endDate,
    })
    .from(calendarEvents)
    .where(eq(calendarEvents.status, "confirmed"))
    .orderBy(asc(calendarEvents.startDate));
  return rows;
}

/**
 * Events for the EXPORT feed, optionally excluding one source so an OTA
 * never receives its own bookings back (prevents the feedback loop).
 */
export async function listFeedEvents(
  excludeSource?: CalendarSource,
): Promise<CalendarEvent[]> {
  const where = excludeSource
    ? and(
        eq(calendarEvents.status, "confirmed"),
        ne(calendarEvents.source, excludeSource),
      )
    : eq(calendarEvents.status, "confirmed");

  return db
    .select()
    .from(calendarEvents)
    .where(where)
    .orderBy(asc(calendarEvents.startDate));
}

/**
 * Does [start,end) overlap any existing confirmed event?
 * Half-open overlap rule: existing.start < new.end AND existing.end > new.start.
 */
export async function hasOverlap(
  startDate: string,
  endDate: string,
): Promise<boolean> {
  const rows = await db
    .select({ id: calendarEvents.id })
    .from(calendarEvents)
    .where(
      and(
        eq(calendarEvents.status, "confirmed"),
        lt(calendarEvents.startDate, endDate),
        gt(calendarEvents.endDate, startDate),
      ),
    )
    .limit(1);
  return rows.length > 0;
}

/** Create a manual admin block (Airbnb-style "block these dates"). */
export async function createManualBlock(input: {
  startDate: string;
  endDate: string;
  title?: string | null;
  note?: string | null;
}): Promise<CalendarEvent> {
  const [row] = await db
    .insert(calendarEvents)
    .values({
      source: "manual",
      externalUid: null,
      startDate: input.startDate,
      endDate: input.endDate,
      title: input.title ?? "Blocked by host",
      note: input.note ?? null,
      status: "confirmed",
    })
    .returning();
  return row;
}

/** Remove a manual/direct block. Refuses to delete OTA-imported rows. */
export async function deleteOwnedEvent(id: string): Promise<boolean> {
  const result = await db
    .delete(calendarEvents)
    .where(
      and(
        eq(calendarEvents.id, id),
        inArray(calendarEvents.source, OWNED_SOURCES),
      ),
    )
    .returning({ id: calendarEvents.id });
  return result.length > 0;
}

/**
 * Replace ALL events for one OTA source with a fresh snapshot, atomically.
 * Because an OTA feed is the full current state, delete-then-insert makes
 * cancellations & modifications self-healing. Manual/direct rows untouched.
 */
export async function replaceSourceEvents(
  source: CalendarSource,
  events: Array<{
    externalUid: string;
    startDate: string;
    endDate: string;
    title?: string | null;
  }>,
): Promise<number> {
  return db.transaction(async (tx) => {
    await tx
      .delete(calendarEvents)
      .where(eq(calendarEvents.source, source));

    if (events.length === 0) return 0;

    const rows: NewCalendarEvent[] = events.map((e) => ({
      source,
      externalUid: e.externalUid,
      startDate: e.startDate,
      endDate: e.endDate,
      title: e.title ?? "Reserved",
      status: "confirmed" as const,
    }));

    await tx.insert(calendarEvents).values(rows);
    return rows.length;
  });
}
