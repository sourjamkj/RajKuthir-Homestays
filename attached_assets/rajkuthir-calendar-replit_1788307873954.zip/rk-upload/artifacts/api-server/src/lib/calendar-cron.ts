/**
 * artifacts/api-server/src/lib/calendar-cron.ts
 *
 * Auto-imports OTA feeds on a schedule so availability stays fresh even
 * when nobody is logged in. Call startCalendarCron() once from index.ts.
 *
 *   npm i node-cron   (and @types/node-cron as a dev dep)
 *
 * NOTE: this only works on an always-on host (Reserved VM / Railway / VPS),
 * not on scale-to-zero deployments.
 */
import cron from "node-cron";
import { replaceSourceEvents } from "./calendar-repo";
import { logger } from "./logger";

type ImportSource = "bookingCom" | "airbnb" | "makeMyTrip";

const FEEDS: Record<ImportSource, string | undefined> = {
  bookingCom: process.env.RAJ_KUTHIR_BOOKING_ICAL_URL,
  airbnb: process.env.RAJ_KUTHIR_AIRBNB_ICAL_URL,
  makeMyTrip: process.env.RAJ_KUTHIR_MAKEMYTRIP_ICAL_URL,
};

// Re-use the parser + fetch from the route module, OR duplicate lightly here.
// To avoid circular imports, import the small helpers you export from a shared
// file. For brevity this expects parseIcs + fetchFeed exported from ./ics-utils
import { fetchFeed, parseIcs } from "./ics-utils";

async function runOnce(): Promise<void> {
  for (const source of Object.keys(FEEDS) as ImportSource[]) {
    const url = FEEDS[source];
    if (!url) continue;
    try {
      const events = parseIcs(await fetchFeed(url), source);
      const count = await replaceSourceEvents(source, events);
      logger.info({ source, count }, "cron: calendar synced");
    } catch (err) {
      logger.warn(
        { source, err: err instanceof Error ? err.message : String(err) },
        "cron: calendar sync failed",
      );
    }
  }
}

export function startCalendarCron(): void {
  // Every 2 hours, on the hour. Adjust to "*/30 * * * *" for every 30 min.
  cron.schedule("0 */2 * * *", () => {
    runOnce().catch((err) => logger.error({ err }, "cron: unhandled"));
  });

  // Also run once shortly after boot so a fresh deploy isn't empty.
  setTimeout(() => {
    runOnce().catch((err) => logger.error({ err }, "cron: boot run failed"));
  }, 10_000);

  logger.info("Calendar cron scheduled (every 2h).");
}
