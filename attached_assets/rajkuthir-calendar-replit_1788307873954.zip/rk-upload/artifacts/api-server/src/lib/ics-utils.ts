/**
 * artifacts/api-server/src/lib/ics-utils.ts
 *
 * Shared iCal fetch + parse helpers, used by BOTH the route (/calendar/sync)
 * and the cron job. Keeping them here avoids a circular import.
 *
 * TIP: in calendar.ts you can delete the inline copies and instead do:
 *   import { fetchFeed, parseIcs, type ParsedEvent } from "../lib/ics-utils";
 */

export type ImportSource = "bookingCom" | "airbnb" | "makeMyTrip";

export type ParsedEvent = {
  externalUid: string;
  startDate: string; // YYYY-MM-DD (inclusive)
  endDate: string; // YYYY-MM-DD (exclusive checkout)
  title: string | null;
};

export function isSafeFeedUrl(value: string): boolean {
  try {
    const url = new URL(value);
    if (!["http:", "https:"].includes(url.protocol)) return false;
    const h = url.hostname.toLowerCase();
    if (
      h === "localhost" ||
      h.endsWith(".local") ||
      h === "0.0.0.0" ||
      h === "::1" ||
      h.startsWith("127.") ||
      h.startsWith("10.") ||
      h.startsWith("192.168.") ||
      h.startsWith("169.254.") ||
      h.startsWith("fc") ||
      h.startsWith("fd")
    ) {
      return false;
    }
    return !/^172\.(1[6-9]|2\d|3[01])\./.test(h);
  } catch {
    return false;
  }
}

function unfold(value: string): string[] {
  const norm = value.replace(/\r\n/g, "\n").replace(/\r/g, "\n");
  const out: string[] = [];
  for (const line of norm.split("\n")) {
    if ((line.startsWith(" ") || line.startsWith("\t")) && out.length) {
      out[out.length - 1] += line.slice(1);
    } else out.push(line);
  }
  return out;
}

function prop(lines: string[], name: string): string | null {
  const line = lines.find(
    (l) => l.startsWith(`${name}:`) || l.startsWith(`${name};`),
  );
  if (!line) return null;
  const i = line.indexOf(":");
  return i >= 0 ? line.slice(i + 1) : null;
}

function toIsoDate(raw: string): string | null {
  const m = raw.trim().match(/^(\d{4})(\d{2})(\d{2})/);
  return m ? `${m[1]}-${m[2]}-${m[3]}` : null;
}

function unescape(v: string): string {
  return v
    .replace(/\\n/gi, " ")
    .replace(/\\,/g, ",")
    .replace(/\\;/g, ";")
    .replace(/\\\\/g, "\\")
    .trim();
}

export function parseIcs(content: string, _source: ImportSource): ParsedEvent[] {
  const lines = unfold(content);
  const events: ParsedEvent[] = [];
  let cur: string[] | null = null;

  for (const line of lines) {
    if (line === "BEGIN:VEVENT") cur = [];
    else if (line === "END:VEVENT" && cur) {
      const start = prop(cur, "DTSTART");
      const end = prop(cur, "DTEND");
      const status = prop(cur, "STATUS")?.toUpperCase();
      const transp = prop(cur, "TRANSP")?.toUpperCase();
      const s = start ? toIsoDate(start) : null;
      const e = end ? toIsoDate(end) : null;

      if (s && e && status !== "CANCELLED" && transp !== "TRANSPARENT") {
        const uid = prop(cur, "UID") ?? `${s}-${e}-${events.length}`;
        const summary = prop(cur, "SUMMARY");
        events.push({
          externalUid: uid.replace(/[^a-zA-Z0-9_@.-]/g, "-"),
          startDate: s,
          endDate: e,
          title: summary ? unescape(summary) : null,
        });
      }
      cur = null;
    } else if (cur) cur.push(line);
  }
  return events;
}

export async function fetchFeed(url: string): Promise<string> {
  if (!isSafeFeedUrl(url)) throw new Error("Enter a public http(s) feed URL.");
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 12_000);
  try {
    const res = await fetch(url, {
      headers: {
        Accept: "text/calendar,text/plain;q=0.9,*/*;q=0.1",
        "User-Agent": "Raj-Kuthir-Calendar-Sync/1.0",
      },
      signal: controller.signal,
      redirect: "error",
    });
    if (!res.ok) throw new Error(`Feed returned ${res.status}.`);
    const text = await res.text();
    if (text.length > 2_000_000) throw new Error("Feed exceeds 2 MB limit.");
    return text;
  } finally {
    clearTimeout(timeout);
  }
}
