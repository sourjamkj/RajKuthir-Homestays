# Raj Kuthir – DB-backed Calendar bundle

## What's inside (already placed at the correct monorepo paths)

```
artifacts/
  api-server/src/lib/calendar-repo.ts     ← DB access (block/unblock/replace)
  api-server/src/lib/ics-utils.ts         ← shared iCal fetch + parse
  api-server/src/lib/calendar-cron.ts     ← auto-sync every 2h (node-cron)
  api-server/src/routes/calendar.ts       ← REPLACES your existing routes file
  db/src/schema/calendar.ts               ← calendar_events Drizzle table
  api-zod/src/calendar.ts                 ← shared request/response schemas
  raj-kuthir/src/components/AdminCalendar.tsx  ← Airbnb-style block UI
_docs/
  ARCHITECTURE.md                         ← how the whole flow works
  INTEGRATION.md                          ← full step-by-step wiring
```

## How to upload to Replit

1. In Replit's file tree, click the **⋮ (three dots) → Upload folder**, and
   select this unzipped folder — OR drag the `artifacts/` folder onto the file
   tree so it merges into your existing `artifacts/`.
2. ⚠️ `artifacts/api-server/src/routes/calendar.ts` will **overwrite** your old
   routes file — that's intended (it's the upgraded version).
3. Everything else is a NEW file, so nothing else gets clobbered.

## 5 things to do after upload (see _docs/INTEGRATION.md for detail)

1. **Export the new modules from your barrels:**
   ```ts
   // artifacts/db/src/schema/index.ts
   export * from "./calendar";
   // artifacts/api-zod/src/index.ts
   export * from "./calendar";
   ```
2. **Install cron:**
   ```bash
   pnpm --filter @workspace/api-server add node-cron
   pnpm --filter @workspace/api-server add -D @types/node-cron
   ```
3. **Create the table:**
   ```bash
   pnpm --filter @workspace/db drizzle-kit push
   ```
4. **Add the admin allowlist Secret:**
   `RAJ_KUTHIR_ADMIN_USER_IDS = user_xxx` (your Clerk user id)
5. **Start the cron** in `artifacts/api-server/src/index.ts`:
   ```ts
   import { startCalendarCron } from "./lib/calendar-cron";
   if (process.env.NODE_ENV === "production") startCalendarCron();
   ```
   And mount the UI in `App.tsx` inside `<Show when="signed-in">`:
   ```tsx
   import { AdminCalendar } from "./components/AdminCalendar";
   <AdminCalendar />
   ```

## Verify the import paths match YOUR packages

I used `@workspace/db`, `@workspace/db/schema`, `@workspace/api-zod`.
Open each sub-package's `package.json` and confirm the `"name"` matches. If your
names differ, adjust the imports at the top of the .ts files.

## Test locally before deploying
- Sign in → block 2 dates → they appear with an "Unblock" button.
- `curl "localhost:PORT/api/calendar/feed?token=YOURTOKEN"` → shows a VEVENT.
- `/api/calendar/feed-info` → gives 3 per-OTA URLs to paste into each extranet.
