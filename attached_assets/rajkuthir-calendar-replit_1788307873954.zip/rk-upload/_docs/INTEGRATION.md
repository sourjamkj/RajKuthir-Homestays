# Wiring it into your app (step by step)

## File placement

| This file            | Goes to                                                        |
|----------------------|---------------------------------------------------------------|
| `schema.ts`          | `artifacts/db/src/schema/calendar.ts` (export from schema index)|
| `calendar-repo.ts`   | `artifacts/api-server/src/lib/calendar-repo.ts`               |
| `ics-utils.ts`       | `artifacts/api-server/src/lib/ics-utils.ts`                   |
| `calendar.ts`        | `artifacts/api-server/src/routes/calendar.ts` (REPLACE)        |
| `calendar-cron.ts`   | `artifacts/api-server/src/lib/calendar-cron.ts`               |
| `calendar-zod.ts`    | `artifacts/api-zod/src/calendar.ts` (export from index)        |
| `AdminCalendar.tsx`  | `artifacts/raj-kuthir/src/components/AdminCalendar.tsx`        |

## 1. Database
```bash
# after adding schema.ts and exporting it from your schema index
pnpm --filter @workspace/db drizzle-kit push
```

## 2. Env vars (add the new one)
```
RAJ_KUTHIR_ADMIN_USER_IDS=user_2abc...    # your Clerk user id(s), comma-separated
RAJ_KUTHIR_CALENDAR_FEED_TOKEN=<long-random-string>
RAJ_KUTHIR_BOOKING_ICAL_URL=<booking export url>
RAJ_KUTHIR_AIRBNB_ICAL_URL=<airbnb export url>
RAJ_KUTHIR_MAKEMYTRIP_ICAL_URL=<mmt export url>
```
Find your Clerk user id in the Clerk dashboard → Users → click yourself → copy the `user_...` id.

## 3. Optional: de-duplicate the parser
`calendar.ts` ships with an inline copy of `fetchFeed`/`parseIcs` so it works
stand-alone. If you also use the cron, switch the route to the shared module:
```ts
// top of calendar.ts
import { fetchFeed, parseIcs } from "../lib/ics-utils";
// then delete the inline unfold/prop/toIsoDate/parseIcs/fetchFeed/isSafeFeedUrl
```

## 4. Start the cron (index.ts)
```ts
import { startCalendarCron } from "./lib/calendar-cron";
// after app is listening:
if (process.env.NODE_ENV === "production") startCalendarCron();
```
```bash
pnpm --filter @workspace/api-server add node-cron
pnpm --filter @workspace/api-server add -D @types/node-cron
```

## 5. Mount the admin calendar (App.tsx)
Inside your existing `<Show when="signed-in">` admin block:
```tsx
import { AdminCalendar } from "./components/AdminCalendar";
...
<Show when="signed-in">
  <AdminCalendar />
  {/* keep your existing Sync button + feed-info panel */}
</Show>
```

## 6. Point OTAs at the PER-OTA export URLs
Open `/api/calendar/feed-info` while signed in. It now returns three URLs:
```
bookingCom  → paste into Booking.com's "import calendar"
airbnb      → paste into Airbnb's "import calendar"
makeMyTrip  → paste into MMT's "import calendar"
```
Each already carries the correct `?exclude=` so no OTA gets its own bookings back.

## 7. Public availability calendar
Your guest-facing page can now call `GET /api/calendar/public` (no auth) and grey
out the returned ranges. It returns only `{startDate, endDate}` — no guest data.

## Quick manual test (local)
1. Sign in as admin → open the calendar → select 2 dates → "Block".
2. Refresh: the block appears in the list with an "Unblock" button.
3. `curl "localhost:PORT/api/calendar/feed?token=YOURTOKEN"` → see the VEVENT.
4. `curl ".../feed?token=YOURTOKEN&exclude=manual"` → the manual block is gone.
5. Hit "Sync" with one OTA URL → rows persist (re-check `/events`).

## What this fixed vs your old code
- ❌ In-memory-only sync  → ✅ persisted to Postgres
- ❌ Feed re-broadcast OTA events back (loop) → ✅ per-OTA `exclude`
- ❌ Any signed-in user = admin → ✅ Clerk user-id allowlist
- ❌ No manual blocking → ✅ Airbnb-style block/unblock UI
- ❌ No auto-refresh → ✅ node-cron every 2h
- ➕ Public availability endpoint with no PII leak
