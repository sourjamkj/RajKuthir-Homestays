# Raj Kuthir – DB-backed Calendar & iCal Sync

## The core idea

Your database becomes the **single source of truth**. Everything reads from and
writes to one table (`calendar_events`). No more in-memory-only sync, no more
re-broadcasting OTA feeds back at themselves.

```
                         ┌──────────────────────────┐
   OTA iCal feeds  ──▶   │   IMPORT (cron + button) │
   (Booking/Airbnb/MMT)  │  full-snapshot replace    │
                         └────────────┬─────────────┘
                                      │ upsert
                                      ▼
   Admin blocks a range  ──▶  ┌───────────────────┐
   (Airbnb-style UI)          │  calendar_events  │  ◀── single source of truth
                              │  (Postgres/Drizzle)│
   Direct website booking ──▶ └─────────┬─────────┘
                                        │ read
                    ┌───────────────────┼────────────────────┐
                    ▼                   ▼                    ▼
          Public availability   Admin calendar UI    EXPORT iCal feed
          calendar on "/"       (block / unblock)    /calendar/feed
                                                     (per-OTA, no loop)
```

## The `source` field is everything

Every row has a `source`:

| source        | created by            | editable in UI | included in export feed |
|---------------|-----------------------|----------------|--------------------------|
| `manual`      | admin (block dates)   | ✅ yes         | ✅ yes                   |
| `direct`      | website booking       | ✅ yes         | ✅ yes                   |
| `bookingCom`  | Booking.com import    | ❌ no          | ⚠️ only to *other* OTAs |
| `airbnb`      | Airbnb import         | ❌ no          | ⚠️ only to *other* OTAs |
| `makeMyTrip`  | MakeMyTrip import     | ❌ no          | ⚠️ only to *other* OTAs |

## How the feedback loop is fixed

The export feed takes an `exclude` parameter. You give **each OTA its own URL**:

```
Booking.com imports →  /api/calendar/feed?token=XXX&exclude=bookingCom
Airbnb imports      →  /api/calendar/feed?token=XXX&exclude=airbnb
MakeMyTrip imports  →  /api/calendar/feed?token=XXX&exclude=makeMyTrip
```

So Booking.com never receives its own bookings back (no loop), but it DOES
receive your manual blocks, your direct bookings, AND Airbnb + MMT bookings —
which is exactly what prevents cross-OTA double-booking.

## How cancellations are handled automatically

An OTA feed is a **full snapshot** of current bookings. When a guest cancels, the
event simply disappears from their feed. So on every import we do, **inside one
transaction**, for that one source:

```
DELETE all rows WHERE source = 'bookingCom'
INSERT the fresh parsed events
```

Manual and direct rows are never touched by import, so nothing you created by hand
is ever lost. This "delete-and-replace per source" is the simplest correct way to
reflect cancellations and modifications.

## Date convention (critical)

- `start_date` = check-in / first blocked night (INCLUSIVE)
- `end_date`   = check-out (EXCLUSIVE) — the day the guest leaves is free again

A Sep 2 → Sep 5 stay blocks the nights of the 2nd, 3rd, 4th. The 5th is bookable.
This matches Airbnb/Booking iCal semantics, so import and export line up perfectly.

## Endpoints

| Method | Route                         | Auth        | Purpose                              |
|--------|-------------------------------|-------------|--------------------------------------|
| GET    | /api/calendar/events          | admin       | All events for the admin UI          |
| GET    | /api/calendar/public          | none        | Booked/blocked dates for public page |
| POST   | /api/calendar/block           | admin       | Block a date range (manual)          |
| DELETE | /api/calendar/block/:id       | admin       | Unblock (remove a manual block)      |
| POST   | /api/calendar/sync            | admin       | Import all OTA feeds → DB            |
| GET    | /api/calendar/feed            | feed token  | Export iCal (with ?exclude=source)   |
| GET    | /api/calendar/feed-info       | admin       | Shows the 3 per-OTA feed URLs        |

## Build / test order (works locally, no deploy needed)

1. Add the Drizzle schema, run `drizzle-kit push` against your dev DB.
2. Drop in the repository functions.
3. Replace `calendar.ts` routes.
4. Add the Zod schemas.
5. Mount the `<AdminCalendar/>` component behind your Clerk `<Show when="signed-in">`.
6. Test manual block/unblock locally.
7. Test `/sync` with one OTA feed, confirm rows persist.
8. Point each OTA at its per-OTA export URL when you deploy.
